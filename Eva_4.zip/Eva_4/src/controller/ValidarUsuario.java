package controller;

import java.io.Serializable;

public class ValidarUsuario implements Serializable{
	
	private String usuario;
	private String clave;
	
	
	
	public ValidarUsuario(String usuario1, String clave1) {
		super();
		this.usuario = usuario1;
		this.clave = clave1;
	}
	
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getClave() {
		return clave;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
	
	public boolean validar(String usuario1, String clave1) {
		if (usuario1.equals(usuario) && clave1.equals(clave)) 
            return true; 
        else
            return false; 
	}

}
